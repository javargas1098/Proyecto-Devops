import unittest
import requests
from vistas import *
from modelos import *
import json
import random

globalList_schema = GlobalListSchema()
user_schema = UserSchema()


class DriverTestCase(unittest.TestCase):
    
    def test_passing(self):
        print("test123421332131")
        assert (1, 2, 3) == (1, 2, 3)
    
    # def test_create_blacklist(self):
    #     requets = requests.post('https://proyecto-ionic-grupo21.herokuapp.com/usuario/1/canciones', json={
    #         "titulo": nombre,
    #         "minutos": "2",
    #         "segundos": "22",
    #         "interprete": nombre2,
    #         "genero": genero
    #     })
    #     cancion = requets.json()['id']
    #     VistasCancionesUsuario.post(self, 1, cancion, 2)
    #     prueba = VistaCanciones.get(self, 2)
    #     self.assertEqual(len(prueba), len(prueba))
        
if __name__ == "__main__":
    unittest.main()